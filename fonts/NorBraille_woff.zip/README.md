# NorBraille_woff.zip content

In this zip file you'll find the woff2 and the woff version of the fonts, 6 and 8 dot, with and without shadow dots. Additionally it contains a css style sheet file with entries for each of the provided fonts.

Although letters, numbers and punctuations are represented with braille dots, the importen part of the fonts is the Unicode braille block, which should be useful internationally. Using Unicode Braille, you're sure that the dots showed on screen will read the same on a braille display.
