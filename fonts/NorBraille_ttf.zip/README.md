# NorBraille_ttf.zip content

In this zip file you'll find the ttf version of the fonts, 6 and 8 dot, with and without shadow dots.

Although letters, numbers and punctuations are represented with braille dots, the important part of the fonts is the Unicode braille block, which should be useful internationally. Using Unicode Braille, you're sure that the dots showed on screen will read the same on a braille display.

The files to install for most use cases is NorBraille6ShadowBlankSpace for 6 dot and NorBraille8ShadowBlankSpace for 8 dot braille respectively. In these files you'll find the braille dots with shadow of unraised dots, Except for normal space and U+2800, which are without shadow dots, and make equal blanks.
